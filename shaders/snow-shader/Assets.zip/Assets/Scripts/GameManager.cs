﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class GameManager : MonoBehaviour
{
    public enum Season {WINTER, SPRING, SUMMER, FALL};

    public static GameManager instance;

    public GameObject firstPersonCamera;
    public GameObject thirdPersonCamera;
    private int cameraNum;

    public GameObject objectFolder;
    public GameObject ground;
    public TreeMaker treeMaker;
    public GameObject snowSystem;

    public GameObject elkToHide;

    private Season season;

    void Awake()
    {
        instance = this;
    }

    // Start is called before the first frame update
    void Start()
    {
        treeMaker.MakeTrees();

        // set it to winter to begin with
        season = Season.WINTER;
        StartWinter();
        ground.GetComponent<Materials>().ChangeSeason(season);

        firstPersonCamera.SetActive(false);
        thirdPersonCamera.SetActive(true);
        cameraNum = 0;

        UpdateSeason(Season.WINTER);
    }

    public Season GetSeason()
    {
        return season;
    }

    void UpdateSeason(Season newSeason)
    {
        if (season != newSeason) // if actually updating season
        {
            EndSeason();
            switch (newSeason)
            {
                case GameManager.Season.WINTER:
                    StartWinter();
                    break;

                case GameManager.Season.SPRING:
                    StartSpring();
                    break;
                default:
                    break;
            }
            UpdateFolderSeasons(newSeason,objectFolder.transform);
        }
    }

    void UpdateFolderSeasons(Season newSeason, Transform t)
    {
        foreach (Transform child in t)
        {
            if (child.gameObject.activeSelf) // ignore hidden items
            {
                if (child.childCount == 0 && child.gameObject.GetComponent<Materials>() != null)
                {
                    child.gameObject.GetComponent<Materials>().ChangeSeason(newSeason);
                }
                else
                {
                    UpdateFolderSeasons(newSeason, child);
                }
            }
        }
    }

    void EndSeason()
    {
        if (season == Season.WINTER)
        {
            snowSystem.SetActive(false);
            elkToHide.SetActive(false);
        }
    }

    // in charge of changing seasons :)
    void StartWinter()
    {
        print("WINTER");
        season = Season.WINTER;

        snowSystem.SetActive(true);
        elkToHide.SetActive(true);

        Vector3 currentPos = ground.transform.position;
        ground.transform.position = new Vector3(currentPos.x,3.6f,currentPos.z);

    }

    void StartSpring()
    {
        print("SPRING");
        season = Season.SPRING;

        Vector3 currentPos = ground.transform.position;
        ground.transform.position = new Vector3(currentPos.x,3.5f,currentPos.z);
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.Alpha1))
        {
            UpdateSeason(Season.WINTER);
        }

        if (Input.GetKey(KeyCode.Alpha2))
        {
            UpdateSeason(Season.SPRING);
        }

        if (Input.GetKey(KeyCode.Space))
        {
            cameraNum = (cameraNum + 1) % 2;
            if (cameraNum == 0)
            {
                firstPersonCamera.SetActive(false);
                thirdPersonCamera.SetActive(true);
            }
            else
            {
                firstPersonCamera.SetActive(true);
                thirdPersonCamera.SetActive(false);
            }
        }
    }
}
